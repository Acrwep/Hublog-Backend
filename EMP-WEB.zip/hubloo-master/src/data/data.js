import chromeLogo from "../assets/images/Chrome-Logo.png"


 export const streamUserData = [
    {
      name: "John Doe",
      email: "john@example.com",
      browserLogo: chromeLogo,
      browserName: "Chrome",
      activeTime: "7 min ago",
    //   clockLogo: <GoClock />
    },
    {
      name: "Jane Smith",
      email: "jane@example.com",
      browserLogo: chromeLogo,
      browserName: "Chrome",
      activeTime: "7 min ago",
    //   clockLogo: <GoClock />
    },
    {
        name: "John Doe",
        email: "john@example.com",
        browserLogo: chromeLogo,
        browserName: "Chrome",
        activeTime: "7 min ago",
      //   clockLogo: <GoClock />
      },
      {
        name: "Jane Smith",
        email: "jane@example.com",
        browserLogo: chromeLogo,
        browserName: "Chrome",
        activeTime: "7 min ago",
      //   clockLogo: <GoClock />
      },
      {
        name: "John Doe",
        email: "john@example.com",
        browserLogo: chromeLogo,
        browserName: "Chrome",
        activeTime: "7 min ago",
      //   clockLogo: <GoClock />
      },
      {
        name: "Jane Smith",
        email: "jane@example.com",
        browserLogo: chromeLogo,
        browserName: "Chrome",
        activeTime: "7 min ago",
      //   clockLogo: <GoClock />
      },
    // Add more objects as needed
  ];

